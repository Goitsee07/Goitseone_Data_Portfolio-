
-- Remove rows with zero tests
DELETE FROM covid_health_data
WHERE Total_Tests = 0;

-- Create positivity rate column
ALTER TABLE covid_health_data ADD Positivity_Rate FLOAT;

UPDATE covid_health_data
SET Positivity_Rate = Positive_Tests * 1.0 / NULLIF(Total_Tests, 0);
