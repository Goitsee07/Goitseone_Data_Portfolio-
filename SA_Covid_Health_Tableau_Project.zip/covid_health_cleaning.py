
import pandas as pd

# Load data
df = pd.read_csv('SA_Covid_Health_System.csv')

# Convert date column
df['Date'] = pd.to_datetime(df['Date'])

# Remove any rows with missing or zero tests
df = df[df['Total_Tests'] > 0]

# Add a positivity rate column
df['Positivity_Rate'] = df['Positive_Tests'] / df['Total_Tests']

# Aggregate to national level monthly (optional)
monthly_national = df.groupby('Date').agg({
    'Total_Tests': 'sum',
    'Positive_Tests': 'sum',
    'Hospital_Admissions': 'sum',
    'ICU_Capacity': 'sum',
    'Vaccinations': 'sum'
}).reset_index()
monthly_national['Positivity_Rate'] = monthly_national['Positive_Tests'] / monthly_national['Total_Tests']

# Save cleaned version
df.to_csv('Cleaned_SA_Covid_Health_System.csv', index=False)
